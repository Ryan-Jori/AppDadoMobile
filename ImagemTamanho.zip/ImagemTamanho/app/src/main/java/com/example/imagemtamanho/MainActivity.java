package com.example.imagemtamanho;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    private ImageView imageViewdado;
    SeekBar seekBar;
    Button button;
    Random rng = new Random();
    final int[] inds = new int[]{
            R.drawable.f1,
            R.drawable.f2,
            R.drawable.f3,
            R.drawable.f4,
            R.drawable.f5,
            R.drawable.f6};

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageViewdado = findViewById(R.id.imageView_dado);
        button = findViewById(R.id.buttonVer);
        imageViewdado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rollDice();
            }
        });

        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                imageViewdado.setVisibility(View.VISIBLE);
            }
        });


        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
               float scale = ((i / 100.0f) + 1);
               imageViewdado.setScaleX(scale);
               imageViewdado.setScaleY(scale);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                imageViewdado.setVisibility(View.VISIBLE);
            }
           @Override
           public void onStopTrackingTouch(SeekBar seekBar) {
               imageViewdado.setVisibility(View.INVISIBLE);
            }

        });

    }

    public void rollDice() {
        int i = rng.nextInt(6);
        imageViewdado.setImageResource(inds[i]);

            }
}
